var video = document.getElementById('vid');
video.playbackRate  = 0.4;

